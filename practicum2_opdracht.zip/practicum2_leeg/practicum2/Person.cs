﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace practicum2
{
    class Person
    {
        public String Name { get; set; }
    }
}
